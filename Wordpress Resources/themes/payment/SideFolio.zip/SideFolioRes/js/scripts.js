$(document).ready(function() {
	
        $('.header_menu li').hover(
            function () {
                $('ul:first', this).css('display','block');
            }, 
            function () {
                $('ul:first', this).css('display','none');         
            }
        );               				
	    
	$('.header_spacing').css('height', $('#header').outerHeight() + 'px');
	    
	$('#main_header_menu').slicknav();
	    
	$('#maximage').maximage({
		cycleOptions: {
			fx: 'fade',
			speed: 1000, // Has to match the speed for CSS transitions in jQuery.maximage.css (lines 30 - 33)
			timeout: 5000,
			prev: '#arrow_left',
			next: '#arrow_right',
			pause: 1,
			before: function(last,current){
				if(!$.browser.msie){
					// Start HTML5 video when you arrive
					if($(current).find('video').length > 0) $(current).find('video')[0].play();
				}
			},
			after: function(last,current){
				if(!$.browser.msie){
					// Pauses HTML5 video when you leave it
					if($(last).find('video').length > 0) $(last).find('video')[0].pause();
				}
			}
		},
		onFirstImageLoaded: function(){
			$('#cycle-loader').hide();
			$('#maximage').fadeIn('fast');
		}
	});
	// Helper function to Fill and Center the HTML5 Video
	$('video,object').maximage('maxcover');
	// To show it is dynamic html text
	//$('.in-slide-content').delay(1200).fadeIn();
	    
});
$(window).load(function() {
	$('.header_spacing').css('height', $('#header').outerHeight() + 'px');
	if(!$('.header_menu').is(':visible'))
		$('#header').css('top',$('.slicknav_menu').outerHeight() + 'px');
	else
		$('#header').css('top','0px');
});
$(window).scroll(function() {
	$('.header_spacing').css('height', $('#header').outerHeight() + 'px');
	
});
$(window).resize(function() {
	if(!$('.header_menu').is(':visible'))
		$('#header').css('top',$('.slicknav_menu').outerHeight() + 'px');	
	else
		$('#header').css('top','0px');	
});