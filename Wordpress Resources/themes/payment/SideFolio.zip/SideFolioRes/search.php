<?php get_header(); ?>	
<div id="content">
	<div class="container">
	
		<div class="single_left single_left_full">
	
			<div class="home_latest_cont">
			
				<div id="posts_cont">
			
					<?php
					global $wp_query;
					$args = array_merge( $wp_query->query, array( 'posts_per_page' => -1 ) );
					query_posts( $args );        
					$x = 0;
					while (have_posts()) : the_post(); ?>     	
					
						<div class="home_latest_box <?php if ($x == 2) { echo 'home_latest_box_last'; } ?>">
							<p>
								<?php if(get_post_meta( get_the_ID(), 'page_featured_type', true ) == 'youtube') { ?>
									<iframe width="560" height="315" src="http://www.youtube.com/embed/<?php echo get_post_meta( get_the_ID(), 'page_video_id', true ); ?>" frameborder="0" allowfullscreen></iframe>
								<?php } elseif(get_post_meta( get_the_ID(), 'page_featured_type', true ) == 'vimeo') { ?>
									<iframe src="http://player.vimeo.com/video/<?php echo get_post_meta( get_the_ID(), 'page_video_id', true ); ?>?title=0&amp;byline=0&amp;portrait=0&amp;color=085e17" width="500" height="338" frameborder="0" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe>
								<?php } else { ?>
									<a href="<?php the_permalink(); ?>"><?php the_post_thumbnail('home-featured'); ?></a>
								<?php } ?>																
							</p>
							<h3><a href="<?php the_permalink(); ?>"><?php the_title(); ?></a></h3>
						</div><!--//home_latest_box-->			
					
					<?php if($x == 2) { echo '<div class="home_latest_box clear"></div>'; $x = -1; } ?>
					<?php $x++; ?>
					<?php endwhile; ?>		
					<div class="clear"></div>
					
				</div><!--//posts_cont-->
			</div><!--//home_latest_cont-->
			
		</div><!--//single_left_full-->
		
		<div class="clear"></div>			
		
	</div><!--//container-->
</div><!--//content-->
<?php get_footer(); ?> 		