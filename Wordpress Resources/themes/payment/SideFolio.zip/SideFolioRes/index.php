<?php get_header(); ?>
<a href="" id="arrow_left"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/arrow_left.png" alt="Slide Left" /></a>
<a href="" id="arrow_right"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/arrow_right.png" alt="Slide Right" /></a>
<img id="cycle-loader" src="<?php bloginfo('stylesheet_directory'); ?>/images/ajax-loader.gif" />
			<!--<div class="video">
				<img src="../lib/images/demo/pattern.jpg" alt="" />
				<iframe width="100%" height="100%" src="http://www.youtube.com/embed/KVwSP51KVO8?wmode=opaque" frameborder="0" class="youtube-video" allowfullscreen></iframe>
			</div>-->
<div id="maximage">
			<?php
			$slider_arr = array();
			$x = 0;
			$args = array(
				 //'category_name' => 'blog',
				 'post_type' => 'post',
				 'meta_key' => 'ex_show_in_slideshow',
				 'meta_value' => 'Yes',
				 'posts_per_page' => 99
				 );
			query_posts($args);
			while (have_posts()) : the_post(); 
			
				$thumb = wp_get_attachment_image_src( get_post_thumbnail_id(get_the_ID()), 'full' );
				$img_url = $thumb['0']; 			
			?>        
			
				<?php if(get_post_meta( get_the_ID(), 'page_featured_type', true ) == 'youtube') { ?>
					<div class="video"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/pattern.jpg" alt="" /><iframe width="100%" height="100%" src="http://www.youtube.com/embed/<?php echo get_post_meta( get_the_ID(), 'page_video_id', true ); ?>?wmode=opaque" class="youtube-video" frameborder="0" allowfullscreen></iframe></div>
				<?php } elseif(get_post_meta( get_the_ID(), 'page_featured_type', true ) == 'vimeo') { ?>
					<div class="video"><img src="<?php bloginfo('stylesheet_directory'); ?>/images/pattern.jpg" alt="" /><iframe src="http://player.vimeo.com/video/<?php echo get_post_meta( get_the_ID(), 'page_video_id', true ); ?>?title=0&amp;byline=0&amp;portrait=0&amp;color=085e17" width="100%" height="100%" frameborder="0" class="youtube-video" webkitAllowFullScreen mozallowfullscreen allowFullScreen></iframe></div>
				<?php } else { ?>
					<img src="<?php echo $img_url; ?>" alt="image" onclick="alert('test');" />
				<?php } ?>				
			
			<?php array_push($slider_arr,get_the_ID()); ?>
			<?php $x++; ?>
			<?php endwhile; ?>
			<?php wp_reset_query(); ?>                                    				
</div>
<?php get_footer(); ?>